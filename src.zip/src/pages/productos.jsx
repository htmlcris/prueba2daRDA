import CardProducto from '../components/CardProducto';

function Productos() {
    return(
        <div class="bg bg-info">
            <h3 class="badge bg-secondary">Mi lista de productos</h3>
            <div className="row">
            <CardProducto nombre="Pilsener" precio={5} disponible={false} stock={16}/>
            <CardProducto nombre="Club" precio={6} disponible={true} stock={6}/>
            <CardProducto nombre="Caran" precio={10} disponible={true} stock={4}/>
            <CardProducto nombre="Switch" precio={8.12} disponible={true} stock={8}/>
            </div>
        </div>
    )
};

export default Productos;