function CardProducto({ nombre, precio, disponible, stock }) {
    let iva = precio * 0.15;
    let total = precio + iva;
    return (
        <div className="card" style={{ width: '18rem' }}>  
            <div className="card-body">
                <h5 className="card-title badge bg-success">{nombre}</h5>
                <p className="card-text">Producto a precio ${precio}.</p>
                <p className="mb-1">Precio: ${precio.toFixed(2)}</p>
                <p className="fw-bold">IVA: ${iva.toFixed(2)}</p>
                <p className="fw-bold badge bg-success">Total: ${total.toFixed(2) }</p><br></br>

                <span className={disponible ? 'bg-success badge' : 'bg-danger badge'}>
                    {disponible ? 'Disponible' : 'Agotado'}
                </span><br></br>

                <span className={stock > 10 ? 'bg-success badge' : stock < 5 ? 'bg-danger badge ' : 'bg-warning badge text-dark'}>
                    {stock > 10 ? 'Disponible' : stock < 5 ? 'Riesgo' : 'Se termina'}
                </span>

                <a href="#" className="btn btn-primary">Ver mas</a>
            </div>
        </div>
    );
};

export default CardProducto;